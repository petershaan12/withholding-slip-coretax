"""Reusable utility helpers."""
